import requests
from bs4 import BeautifulSoup
import pandas as pd

# Example: Scrape Flipkart for "Mouse"
search_query = "mouse"
url = f"https://www.flipkart.com/search?q={search_query}"

headers = {'User-Agent': 'Mozilla/5.0'}
response = requests.get(url, headers=headers)
soup = BeautifulSoup(response.text, 'html.parser')

products = []
for product in soup.find_all('div', {'class':'_1AtVbE'}):
    name = product.find('a', {'class':'IRpwTa'})
    price = product.find('div', {'class':'_30jeq3'})
    if name and price:
        products.append({'Name': name.text, 'Price': price.text})

# Save to Excel
df = pd.DataFrame(products)
df.to_excel('products.xlsx', index=False)
print("Scraped data saved to products.xlsx")
