import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html

# Load CSV
# df = pd.read_csv('Task1_CRUD/sales.csv')

df = pd.read_csv(r"C:\SHREE_DOC\Data_Analyst_Assignment\Task1_CRUD\sales.csv")



# Descriptive Analysis
print(df.describe())

# Dash App
app = Dash(__name__)

app.layout = html.Div([
    html.H1("Sales Dashboard"),
    dcc.Graph(
        id='bar-chart',
        figure=px.bar(df, x='Product', y='Quantity', color='Product', title='Quantity Sold by Product')
    ),
    dcc.Graph(
        id='line-chart',
        figure=px.line(df, x='Date', y='Price', title='Price Over Time')
    ),
    dcc.Graph(
        id='scatter-chart',
        figure=px.scatter(df, x='Quantity', y='Price', color='Product', size='Quantity', title='Quantity vs Price')
    )
])

if __name__ == '__main__':
    app.run(debug=True, port=8051)
