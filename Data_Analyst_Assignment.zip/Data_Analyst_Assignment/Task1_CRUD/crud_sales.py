import pandas as pd

# Load CSV file
df = pd.read_csv(r"C:\SHREE_DOC\Data_Analyst_Assignment\Task1_CRUD\sales.csv")

# ----- READ -----
print("Current Sales Data:")
print(df)

# ----- CREATE -----
new_record = {'OrderID':5, 'Product':'Headset', 'Quantity':4, 'Price':2000, 'Date':'2025-09-05'}
df = pd.concat([df, pd.DataFrame([new_record])], ignore_index=True)
print("\nAfter Adding New Record:")
print(df)

# ----- UPDATE -----
df.loc[df['OrderID'] == 2, 'Price'] = 550  # Update price of OrderID 2
print("\nAfter Updating Record:")
print(df)

# ----- DELETE -----
df = df[df['OrderID'] != 3]  # Remove OrderID 3
print("\nAfter Deleting Record:")
print(df)

# Save back to CSV
df.to_csv('sales.csv', index=False)
print("\nChanges saved to sales.csv")
